var searchData=
[
  ['rubrica_0',['Rubrica',['../classit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_rubrica.html',1,'it::unisa::diem::softeng::servizio']]],
  ['rubricatest_1',['RubricaTest',['../classit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_rubrica_test.html',1,'it::unisa::diem::softeng::servizio']]]
];
