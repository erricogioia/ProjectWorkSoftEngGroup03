var searchData=
[
  ['importa_0',['importa',['../classit_1_1unisa_1_1diem_1_1softeng_1_1persistenza_1_1_gestore_file.html#a5856f6f6c11993c4296ecb4d547f61a5',1,'it.unisa.diem.softeng.persistenza.GestoreFile.importa()'],['../interfaceit_1_1unisa_1_1diem_1_1softeng_1_1persistenza_1_1_interfaccia_gestore_file.html#aa2fd00264e6609bf15ae3f4779f5f653',1,'it.unisa.diem.softeng.persistenza.InterfacciaGestoreFile.importa()']]],
  ['initialize_1',['initialize',['../classit_1_1unisa_1_1diem_1_1softeng_1_1controllo_1_1_controllore_pop_up.html#ad90f054f480d957c2c38293fb9ef4e03',1,'it.unisa.diem.softeng.controllo.ControllorePopUp.initialize()'],['../classit_1_1unisa_1_1diem_1_1softeng_1_1controllo_1_1_controllore_vista_principale.html#a84b05456f10ee9391c8d466831983cdf',1,'it.unisa.diem.softeng.controllo.ControlloreVistaPrincipale.initialize()']]]
];
