var searchData=
[
  ['validacontatto_0',['ValidaContatto',['../classit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_valida_contatto.html',1,'it::unisa::diem::softeng::servizio']]],
  ['validacontattotest_1',['ValidaContattoTest',['../classit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_valida_contatto_test.html',1,'it::unisa::diem::softeng::servizio']]]
];
