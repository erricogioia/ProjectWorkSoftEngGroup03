var indexSectionsWithContent =
{
  0: "acegimprstv",
  1: "cgimprv",
  2: "acegimprstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "Funzioni"
};

