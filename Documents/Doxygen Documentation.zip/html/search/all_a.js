var searchData=
[
  ['valida_0',['valida',['../interfaceit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_interfaccia_valida_contatto.html#a2488d8c624f978ea3e0ac89c5b1847d8',1,'it.unisa.diem.softeng.servizio.InterfacciaValidaContatto.valida()'],['../classit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_valida_contatto.html#ae3eefe1b3b238d9f7af777ed1b4a2e06',1,'it.unisa.diem.softeng.servizio.ValidaContatto.valida()']]],
  ['validacontatto_1',['ValidaContatto',['../classit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_valida_contatto.html',1,'it::unisa::diem::softeng::servizio']]],
  ['validacontattotest_2',['ValidaContattoTest',['../classit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_valida_contatto_test.html',1,'it::unisa::diem::softeng::servizio']]]
];
