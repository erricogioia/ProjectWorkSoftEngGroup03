var searchData=
[
  ['persona_0',['Persona',['../classit_1_1unisa_1_1diem_1_1softeng_1_1modello_1_1_persona.html',1,'it::unisa::diem::softeng::modello']]],
  ['personatest_1',['PersonaTest',['../classit_1_1unisa_1_1diem_1_1softeng_1_1modello_1_1_persona_test.html',1,'it::unisa::diem::softeng::modello']]]
];
