var searchData=
[
  ['main_0',['Main',['../classit_1_1unisa_1_1diem_1_1softeng_1_1controllo_1_1_main.html',1,'it::unisa::diem::softeng::controllo']]]
];
