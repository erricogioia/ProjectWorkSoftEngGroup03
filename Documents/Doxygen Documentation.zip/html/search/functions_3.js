var searchData=
[
  ['getcognome_0',['getCognome',['../classit_1_1unisa_1_1diem_1_1softeng_1_1modello_1_1_persona.html#a4cac0323f302f9ec49990cbe4ab8ed44',1,'it::unisa::diem::softeng::modello::Persona']]],
  ['getcontatti_1',['getContatti',['../interfaceit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_interfaccia_rubrica.html#ad8f0205f8e7cd4585fc6f6efa53a6610',1,'it.unisa.diem.softeng.servizio.InterfacciaRubrica.getContatti()'],['../classit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_rubrica.html#ad67f1693cfdb12f746448a6398ed9eaf',1,'it.unisa.diem.softeng.servizio.Rubrica.getContatti()']]],
  ['getemail_2',['getEmail',['../classit_1_1unisa_1_1diem_1_1softeng_1_1modello_1_1_contatto.html#aa947d806e6c2642bc32807bb3f04460e',1,'it::unisa::diem::softeng::modello::Contatto']]],
  ['getnome_3',['getNome',['../classit_1_1unisa_1_1diem_1_1softeng_1_1modello_1_1_persona.html#a7b5a4683b24bfd44d4704bf35680f0fb',1,'it::unisa::diem::softeng::modello::Persona']]],
  ['getnumeritelefono_4',['getNumeriTelefono',['../classit_1_1unisa_1_1diem_1_1softeng_1_1modello_1_1_contatto.html#ad3ad2b417e5881ca2f6e516abe421c81',1,'it::unisa::diem::softeng::modello::Contatto']]]
];
