var searchData=
[
  ['setcontatti_0',['setContatti',['../classit_1_1unisa_1_1diem_1_1softeng_1_1controllo_1_1_controllore_pop_up.html#a939620889383964101bcf8abaf3c23b5',1,'it::unisa::diem::softeng::controllo::ControllorePopUp']]],
  ['start_1',['start',['../classit_1_1unisa_1_1diem_1_1softeng_1_1controllo_1_1_main.html#a08c0164ca4106f76c414164b7f7aaabe',1,'it::unisa::diem::softeng::controllo::Main']]]
];
