var searchData=
[
  ['annulla_0',['annulla',['../classit_1_1unisa_1_1diem_1_1softeng_1_1controllo_1_1_controllore_pop_up.html#aa1612c3db4f0c6cc54124d2d10ce3ca5',1,'it::unisa::diem::softeng::controllo::ControllorePopUp']]]
];
