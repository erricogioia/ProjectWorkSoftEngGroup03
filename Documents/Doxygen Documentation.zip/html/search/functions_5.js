var searchData=
[
  ['modifica_0',['modifica',['../classit_1_1unisa_1_1diem_1_1softeng_1_1controllo_1_1_controllore_vista_principale.html#a9b490fa87a3dbd1d3d11531e115e6eb3',1,'it::unisa::diem::softeng::controllo::ControlloreVistaPrincipale']]],
  ['modificacontatto_1',['modificaContatto',['../interfaceit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_interfaccia_rubrica.html#a28faced732c8723fc9b4d6c698711249',1,'it.unisa.diem.softeng.servizio.InterfacciaRubrica.modificaContatto()'],['../classit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_rubrica.html#a78d3ad4b29924520de92682408253081',1,'it.unisa.diem.softeng.servizio.Rubrica.modificaContatto()']]]
];
