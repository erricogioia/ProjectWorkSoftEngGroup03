var searchData=
[
  ['equals_0',['equals',['../classit_1_1unisa_1_1diem_1_1softeng_1_1modello_1_1_persona.html#ac5337261a58febb8e0c26bc1a790bebc',1,'it::unisa::diem::softeng::modello::Persona']]],
  ['esporta_1',['esporta',['../classit_1_1unisa_1_1diem_1_1softeng_1_1persistenza_1_1_gestore_file.html#a0c04e1e10c51dc663218a2eba5d495c9',1,'it.unisa.diem.softeng.persistenza.GestoreFile.esporta()'],['../interfaceit_1_1unisa_1_1diem_1_1softeng_1_1persistenza_1_1_interfaccia_gestore_file.html#a6fd1e74950a061e5423d48bfe07d43b1',1,'it.unisa.diem.softeng.persistenza.InterfacciaGestoreFile.esporta()']]]
];
