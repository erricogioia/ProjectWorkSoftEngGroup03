var searchData=
[
  ['modifica_0',['modifica',['../classit_1_1unisa_1_1diem_1_1softeng_1_1controllo_1_1_controllore_vista_principale.html#a025348896896cacee6c6c665a63a628b',1,'it::unisa::diem::softeng::controllo::ControlloreVistaPrincipale']]],
  ['modificacontatto_1',['modificaContatto',['../interfaceit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_interfaccia_rubrica.html#abb7efdbf060e6bf28916e176168b1030',1,'it.unisa.diem.softeng.servizio.InterfacciaRubrica.modificaContatto()'],['../classit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_rubrica.html#a925a90995c1b8f5de911de7626779720',1,'it.unisa.diem.softeng.servizio.Rubrica.modificaContatto()']]]
];
