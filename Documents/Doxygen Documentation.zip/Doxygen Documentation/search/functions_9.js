var searchData=
[
  ['tostring_0',['toString',['../classit_1_1unisa_1_1diem_1_1softeng_1_1modello_1_1_contatto.html#ad16a53024840d36aa5b2fa542e2750c5',1,'it.unisa.diem.softeng.modello.Contatto.toString()'],['../classit_1_1unisa_1_1diem_1_1softeng_1_1modello_1_1_persona.html#a791a76a9d18aea57cccfdc0d5b0bf45b',1,'it.unisa.diem.softeng.modello.Persona.toString()']]]
];
