var searchData=
[
  ['ricerca_0',['ricerca',['../classit_1_1unisa_1_1diem_1_1softeng_1_1controllo_1_1_controllore_vista_principale.html#a0f7348e17b0772557424db71e0e2ca14',1,'it::unisa::diem::softeng::controllo::ControlloreVistaPrincipale']]],
  ['rimuovi_1',['rimuovi',['../classit_1_1unisa_1_1diem_1_1softeng_1_1controllo_1_1_controllore_vista_principale.html#a19eb1834096482a372741370376e493a',1,'it::unisa::diem::softeng::controllo::ControlloreVistaPrincipale']]],
  ['rimuovicontatto_2',['rimuoviContatto',['../interfaceit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_interfaccia_rubrica.html#aa55549691724246afcb240879bfc6d30',1,'it.unisa.diem.softeng.servizio.InterfacciaRubrica.rimuoviContatto()'],['../classit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_rubrica.html#ab7a8179038a93be2474b7046f472b6a5',1,'it.unisa.diem.softeng.servizio.Rubrica.rimuoviContatto(Contatto contatto)']]],
  ['rubrica_3',['Rubrica',['../classit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_rubrica.html#acc4a4eb52eb8100887140533512321f3',1,'it::unisa::diem::softeng::servizio::Rubrica']]]
];
