var searchData=
[
  ['importa_0',['importa',['../classit_1_1unisa_1_1diem_1_1softeng_1_1persistenza_1_1_gestore_file.html#a5856f6f6c11993c4296ecb4d547f61a5',1,'it.unisa.diem.softeng.persistenza.GestoreFile.importa()'],['../interfaceit_1_1unisa_1_1diem_1_1softeng_1_1persistenza_1_1_interfaccia_gestore_file.html#aa2fd00264e6609bf15ae3f4779f5f653',1,'it.unisa.diem.softeng.persistenza.InterfacciaGestoreFile.importa()']]],
  ['interfacciagestorefile_1',['InterfacciaGestoreFile',['../interfaceit_1_1unisa_1_1diem_1_1softeng_1_1persistenza_1_1_interfaccia_gestore_file.html',1,'it::unisa::diem::softeng::persistenza']]],
  ['interfacciarubrica_2',['InterfacciaRubrica',['../interfaceit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_interfaccia_rubrica.html',1,'it::unisa::diem::softeng::servizio']]],
  ['interfacciavalidacontatto_3',['InterfacciaValidaContatto',['../interfaceit_1_1unisa_1_1diem_1_1softeng_1_1servizio_1_1_interfaccia_valida_contatto.html',1,'it::unisa::diem::softeng::servizio']]]
];
