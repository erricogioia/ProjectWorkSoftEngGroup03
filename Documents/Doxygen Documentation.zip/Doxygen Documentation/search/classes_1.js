var searchData=
[
  ['gestorefile_0',['GestoreFile',['../classit_1_1unisa_1_1diem_1_1softeng_1_1persistenza_1_1_gestore_file.html',1,'it::unisa::diem::softeng::persistenza']]]
];
