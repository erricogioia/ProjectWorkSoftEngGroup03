var searchData=
[
  ['setcognome_0',['setCognome',['../classit_1_1unisa_1_1diem_1_1softeng_1_1modello_1_1_persona.html#aada46ff6436e36f1335c3c777384b1fd',1,'it::unisa::diem::softeng::modello::Persona']]],
  ['setnome_1',['setNome',['../classit_1_1unisa_1_1diem_1_1softeng_1_1modello_1_1_persona.html#aaceb615b4b569051a01eea3b720db306',1,'it::unisa::diem::softeng::modello::Persona']]]
];
